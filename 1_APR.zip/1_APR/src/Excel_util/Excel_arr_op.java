package Excel_util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excel_arr_op {
	//private static final String sheetname = null;

	public static String filename="C:\\Users\\user\\Desktop\\Book1.xlsx", sheetname="keyword";
	
	public static String[][] testdata;
	static int row,col;
	
	public void get_data()
	{
		testdata= new String[2][3];
		String s1,s2,s3;
		for(row=0;row<=4;row++)
		{
			try {
				File f =new File(filename);
				FileInputStream fin = new FileInputStream(f);
				XSSFWorkbook wb = new XSSFWorkbook(fin);
				XSSFSheet sh= wb.getSheet(sheetname);
				XSSFRow r = sh.getRow(row);
				
				XSSFCell cell1 = r.getCell(0);
				testdata[row][0]= cell1.getStringCellValue();
				s1=cell1.getStringCellValue();
				
				XSSFCell cell2 = r.getCell(0);
				testdata[row][1]= cell1.getStringCellValue();
				s2=cell1.getStringCellValue();
				
				XSSFCell cell3 = r.getCell(0);
				testdata[row][2]= cell1.getStringCellValue();
				s3=cell1.getStringCellValue();
				
				System.out.println(s1 + ":" +s2 + ":" +s3);
				
			} catch(FileNotFoundException e) {
		       e.printStackTrace();
		       
			}catch(IOException e) {
				e.printStackTrace();
			}
	}
	}
}
