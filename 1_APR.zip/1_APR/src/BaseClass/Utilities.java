package BaseClass;

import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Utilities {
	
  public static WebDriver launch_browser(String browser,String url)
    {
	WebDriver dr = null;
	String ch_driver_path="C:\\chromedriver_win32\\chromedriver.exe";
	String ff_driver_path="C:\\Users\\user\\Downloads\\geckodriver-v0.26.0-win64\\geckodriver.exe";
	switch(browser)
	{
	case "chrome":
	System.setProperty("webdriver.chrome.driver","chromedriver.exe");
    dr = new ChromeDriver();
	break;
		
	case "firefox" :
	System.setProperty("webdriver.gecko.driver","geckodriver.exe");
	 dr = new FirefoxDriver();
	break;
	
	default:
	System.out.println("Supported browser options : chrome & Firefox");
	break;
	}
       dr.get(url);
       dr.manage().window().maximize();
       dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
       
       return dr;
       }
}
