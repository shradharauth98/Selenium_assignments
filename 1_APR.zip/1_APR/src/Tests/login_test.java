package Tests;

import org.testng.annotations.Test;

import BaseClass.Utilities;
import Excel_util.Excel_arr_op;
import Page.Login_page;
import Page.Profile_page;
import Pages.home_page;
import Pages.login_page;

import org.testng.annotations.DataProvider;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

public class login_test extends Excel_arr_op {
 
	 
		//private static final String[][] testdata = null ;
		WebDriver dr;
		home_page hp;
		login_page lp;
		Profile_page pp;
 
	 @BeforeMethod
		  public void launchbrowser() 
		  {
		       dr=Utilities.launch_browser("firefox", "")
			    hp= new home_page(dr); 
			    lp = new login_page(dr);
			    pp = new Profile_page(dr);
		  }
	 @BeforeClass
	   public void Get_data() {
		 get_login_data();
	 }
		  
	  @Test(dataProvider="login_data")
	  public void logintest1(String username, String pwd, String exp_text)
	  {
		  String exp_pn = "trainingservices06@gmail.com" , act_pn;
		  
		  hp.click_login_link();
		  lp.do_login("trainingservices06@gmail.com","password");
		  act_pn = pp.get_profilename();
		  System.out.println("act_pn :" +act_pn);
		  Assert.assertEquals(act_pn, exp_pn);
	  }
	 @DataProvider(name="login_data")
	 public String[][] get_login_data()
	 {
		 return testdata;
	 }
		
		  
		}
  

