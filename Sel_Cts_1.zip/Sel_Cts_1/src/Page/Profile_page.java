package Page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Profile_page {
	By xp_profilename = By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a");
	WebDriver dr3;
	
	public Profile_page(WebDriver dr)
	{
		dr3 = dr;
	
	}
   public String get_profilename()
   {
	   String pname = dr3.findElement(xp_profilename).getText();
	   return pname;
   }
}
