package Page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Login_page {

	//public static void main(String[] args) {
        
	 WebDriver dr2;
	  
	  By Eid = new By.ById("Email");
	  By Pwd = new By.ById("Password");
	  By Login_btn = new By.ByXPath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input");
	  
	  public Login_page(WebDriver dr)
	  {
		  this.dr2=dr;
	  }
	  public void enter_email_id(String emailid)
	  {
		  dr2.findElement(Eid).sendKeys(emailid);
	  }
	  public void enter_password(String password)
	  {
		  dr2.findElement(Pwd).sendKeys(password);
	  }
	  public void click_login_btn()
	  {
		  dr2.findElement(Login_btn).click();
	  }
	  public void do_login(String emailid, String password)
	  {
		  this.enter_email_id(emailid);
		  this.enter_password(password);
		  this.click_login_btn();
	
	
	}

}
