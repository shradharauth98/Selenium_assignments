package Page;

import org.testng.annotations.Test;

import Pkg_1.HOMEPAGE_1;
import Pkg_1.LOGIN_PAGE;

import org.testng.annotations.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;

public class TestPage2 {
   
	WebDriver dr;
	HOMEPAGE_1 hp;
	LOGIN_PAGE lp;
    Profile_page pp;	
  @BeforeClass
 
	  public void launchbrowser() 
	  {
		   System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		    dr = new ChromeDriver(); 
		    dr.get("http://demowebshop.tricentis.com");
		    hp= new HOMEPAGE_1(dr); 
		    lp = new LOGIN_PAGE(dr);
		    pp = new Profile_page(dr);
	  }
	  
  @Test
  public void logintest1()
  {
	  String exp_pn = "trainingservices06@gmail.com", act_pn;
	  
	  hp.click_login_link();
	  lp.do_login("trainingservices06@gmail.com","password");
	  act_pn = pp.get_profilename();
	  System.out.println("act_pn :"+ act_pn);
	  Assert.assertEquals(act_pn, exp_pn);
	}

 @AfterClass
  public void closebrowser() {
  //dr.close();
  }
}

