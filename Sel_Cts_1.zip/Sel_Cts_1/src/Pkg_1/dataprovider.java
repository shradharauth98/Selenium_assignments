package Pkg_1;

import org.testng.annotations.Test;

import org.testng.annotations.DataProvider;

public class dataprovider {
  @Test(dataProvider = "login_data")
  public void login(String Eid, String Pwd) {
	  System.out.println("Email id :" +Eid +  " Pwd :" +Pwd);
  }

  @DataProvider(name="login_data")
  public String[][] provide_data() 
  {
     String[][] data= {
           {"e1","p1"},
           {"e2","p2"},
           {"e3","p3"}
         
    };
  return data;
  }
}
