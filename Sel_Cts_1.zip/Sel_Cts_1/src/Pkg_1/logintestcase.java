package Pkg_1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class logintestcase {

	public String login()
	
	{
		
   
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		WebDriver dr = new ChromeDriver();
		
		dr.get("http://demowebshop.tricentis.com/login");
		
		dr.findElement(By.linkText("Log in")).click();
		
		dr.findElement(By.id("Email")).sendKeys("trainingservices06@gmail.com");
		
		dr.findElement(By.id("Password")).sendKeys("password");
		
		//tagName[@attribute='value']
		
		//input[@value='Log in]
		
		dr.findElement(By.xpath("//input[@value='Log in']")).click();
		
		String act_res = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
		//String exp_res = "trainingservices06@gmail.com";
		/*
		if(act_res.equals(exp_res))
			System.out.println("Test case PASS");
		else
			System.out.println("Test case FAIL");
*/

     return act_res;
	}

	

}
